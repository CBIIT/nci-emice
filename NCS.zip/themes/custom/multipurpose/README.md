# drupal-multipurpose-theme

## About Multipurpose Theme
Multipurpose Theme is a Drupal 7 theme used as a baseline for NCI websites. 
The theme is not dependent on any core theme. It is very light-weight for 
fast loading and has a modern look. 
